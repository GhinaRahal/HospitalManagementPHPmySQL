/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Doctor;
import model.Patient;

/**
 *
 * @author Zainab
 */
public class DBAccess {
    
    private Connection connection;
    private Statement statement;
    
    private void connect() throws SQLException{
        
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital2", 
                "root", "");
        statement = connection.createStatement();
    
    }
    
    private void close() throws SQLException{
        statement.close();
        connection.close();
    }
    
    public void addDoctor(Doctor doctor){
        
        String query = "INSERT INTO doctor VALUES ("+doctor.getID()+ ", '"
                +doctor.getName()+"', '"+ doctor.getDepartment()+"', '"+ doctor.getDphone_number()+"', '"+doctor.getGender()+"');";
        
        try {
            connect();
            statement.executeUpdate(query);
            close();
            
        } catch (SQLException ex) {
            Logger.getLogger(DBAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
        public void addPatient(Patient patient){
        
        String query = "INSERT INTO patient VALUES ("+patient.getID()+ ", '"
                +patient.getName()+"', '"+ patient.getPphone_number()+"', '"
                + patient.getGender()+"', "+patient.getAge()+", '"+patient.getDisease()+"');";
        
        try {
            connect();
            statement.executeUpdate(query);
            close();
            
        } catch (SQLException ex) {
            Logger.getLogger(DBAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public ArrayList<Integer> getAllDoctorID(){
        
        String query = "SELECT ID from doctor;";
        ArrayList<Integer> IDList = new ArrayList<>();
        
        try {
            connect();
            ResultSet rs = statement.executeQuery(query);
            
            while(rs.next()){
                int ID = rs.getInt("ID");//ID is the name of the column in the database
                IDList.add(ID);
            }
            
            rs.close();
            close();
            
        } catch (SQLException ex) {
            Logger.getLogger(DBAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return IDList;
    }
    
    public Doctor getDoctorByID(int ID){
        
        Doctor doctor = null;
        String query = "SELECT * from doctor where ID="+ID;
        
        try {
            connect();
            ResultSet rs = statement.executeQuery(query);
            
            if (rs.next()){
                doctor = new Doctor();
                
                doctor.setID(ID);
                doctor.setName(rs.getString("Name"));
                doctor.setDepartment(rs.getString("Department"));
                doctor.setDphone_number(rs.getString("Dphone_number"));
                doctor.setGender(rs.getString("Gender"));
                
            }
            
            rs.close();
            close();
            
        } catch (SQLException ex) {
            Logger.getLogger(DBAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return doctor;
    }
    
    public void deleteDoctorByID(int ID){
        
        String query = "Delete from Doctor where ID="+ID;
        
        try {
            connect();
            statement.executeUpdate(query);
            close();
            
        } catch (SQLException ex) {
            Logger.getLogger(DBAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }
    
    public ArrayList<Integer> getAllPatientID(){
        
        String query = "SELECT ID from Patient;";
        ArrayList<Integer> IDList = new ArrayList<>();
        
        try {
            connect();
            ResultSet rs = statement.executeQuery(query);
            
            while(rs.next()){
                int ID = rs.getInt("ID");//ID is the name of the column in the database
                IDList.add(ID);
            }
            
            rs.close();
            close();
            
        } catch (SQLException ex) {
            Logger.getLogger(DBAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return IDList;
    }
    public Patient getPatientByID(int ID){
        
        Patient patient = null;
        String query = "SELECT * from patient where ID="+ID;
        
        try {
            connect();
            ResultSet rs = statement.executeQuery(query);
            
            if (rs.next()){
                patient = new Patient();
                
                patient.setID(ID);
                patient.setName(rs.getString("Name"));
                patient.setPphone_number(rs.getString("Pphone_number"));
                patient.setGender(rs.getString("Gender"));
                patient.setAge(Integer.parseInt(rs.getString("Age")));
                patient.setDisease(rs.getString("Disease"));
                
            }
            
            rs.close();
            close();
            
        } catch (SQLException ex) {
            Logger.getLogger(DBAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return patient;
    }
    public void updatePatientDisease(Patient patient, String disease){
        
        String query = "UPDATE patient SET Disease ='"+disease+"' WHERE ID="+patient.getID()+";";
        
        try {
            connect();
            statement.executeUpdate(query);
            close();
            
        } catch (SQLException ex) {
            Logger.getLogger(DBAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
