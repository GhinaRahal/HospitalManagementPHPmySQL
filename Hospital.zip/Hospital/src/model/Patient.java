/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Zainab
 */
public class Patient {
    
    int ID;
    String Name;
    String Pphone_number;
    String Gender;
    int Age;
    String Disease;

    public Patient() {
    }

    public Patient(int ID, String Name, String Pphone_number, String Gender, int Age, String Disease) {
        this.ID = ID;
        this.Name = Name;
        this.Pphone_number = Pphone_number;
        this.Gender = Gender;
        this.Age = Age;
        this.Disease = Disease;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getPphone_number() {
        return Pphone_number;
    }

    public void setPphone_number(String Pphone_number) {
        this.Pphone_number = Pphone_number;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public int getAge() {
        return Age;
    }

    public void setAge(int Age) {
        this.Age = Age;
    }

    public String getDisease() {
        return Disease;
    }

    public void setDisease(String Disease) {
        this.Disease = Disease;
    }
    
    
    
}
