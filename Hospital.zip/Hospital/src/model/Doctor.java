/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Zainab
 */
public class Doctor {
    
    int ID;
    String name;
    String Department;
    String Dphone_number;
    String Gender;

    public Doctor() {
    }

    public Doctor(int ID, String name, String Department, String Dphone_number, String Gender) {
        this.ID = ID;
        this.name = name;
        this.Department = Department;
        this.Dphone_number = Dphone_number;
        this.Gender = Gender;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String Department) {
        this.Department = Department;
    }

    public String getDphone_number() {
        return Dphone_number;
    }

    public void setDphone_number(String Dphone_number) {
        this.Dphone_number = Dphone_number;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }
    
    
    
}
